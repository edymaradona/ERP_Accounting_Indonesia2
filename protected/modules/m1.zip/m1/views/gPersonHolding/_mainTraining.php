<h3>Holding Training</h3>
<?php echo $this->renderPartial('/gPerson/_tabTrainingHolding', ["model" => $model]); ?>

<h3>Local Training</h3>
<?php echo $this->renderPartial('/gPerson/_tabTraining', ["model" => $model]); ?>

