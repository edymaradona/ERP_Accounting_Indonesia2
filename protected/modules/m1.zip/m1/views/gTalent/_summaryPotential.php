<div class="row">
    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3><?php echo 0 ?></h3>
            <h6><span style="COLOR:"#999;">Year Calculation</span></h6>
        </div>
    </div>

    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3><?php echo 0 ?></h3>
            <h6><span style="COLOR:"#999;">Average</span></h6>
        </div>
    </div>

    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3><?php echo 0 ?></h3>
            <h6><span style="COLOR:"#999;">Performance</span></h6>
        </div>
    </div>
</div>
