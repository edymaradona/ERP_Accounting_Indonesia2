<div class="row">
    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3><?php echo peterFunc::indoFormat(gLoan::model()->lastBalance()) ?></h3>
            <h6><span style="color:#999">Total Loan</span></h6>
        </div>
    </div>

    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3>.</h3>
            <h6><span style="color:#999">.</span></h6>
        </div>
    </div>

    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3>.</h3>
            <h6><span style="color:#999">.</span></h6>
        </div>
    </div>

</div>
