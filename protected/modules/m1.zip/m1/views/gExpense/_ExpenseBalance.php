<div class="row">
    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3><?php //echo peterFunc::indoFormat(gExpense::model()->lastBalance(10)) ?>.</h3>
            <h6><span style="color:#999">Perjalanan Dinas</span></h6>
        </div>
    </div>

    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3>.</h3>
            <h6><span style="color:#999">.</span></h6>
        </div>
    </div>

    <div class="col-md-4">
        <div class="well" style="text-align: center;padding:0">
            <h3>.</h3>
            <h6><span style="color:#999">Return to Homebase</span></h6>
        </div>
    </div>

</div>
