<div class="page-header">
    <h3>New Non Formal Education</h3>
</div>
<?php
echo $this->renderPartial('_formEducationNf', ['model' => $modelEducationNf]);
