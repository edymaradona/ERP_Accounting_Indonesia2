<div class="row">
    <div class="col-md-2">
        <h6>Sex/Gender</h6>
        <ul>
            <li>code name</li>
            <li>1 Male</li>
            <li>2 Female</li>
            <li>3 Kristen Katolik</li>
            <li>4 Budha</li>
            <li>5 Hindu</li>
            <li>6 Kong Hu Cu</li>
        </ul>
    </div>
    <div class="col-md-3">
        <h6>Level Code</h6>
        <ul>
            <li>id name</li>
            <li>2 Executive Vice President</li>
            <li>3 Senior Vice President</li>
            <li>4 Vice President</li>
            <li>6 Assistant Vice President</li>
            <li>25 Senior General Manager</li>
            <li>7 General Manager</li>
            <li>8 Assistant General Manager</li>
            <li>10 Senior Manager</li>
            <li>11 Manager</li>
            <li>12 Assistant Manager</li>
            <li>14 Senior Supervisor</li>
            <li>15 Supervisor</li>
            <li>16 Assistant Supervisor</li>
            <li>18 Senior Officer</li>
            <li>19 Officer</li>
            <li>20 Junior Officer</li>
            <li>22 Senior Support</li>
            <li>23 Support</li>
            <li>24 Junior Support</li>
        </ul>
    </div>
    <div class="col-md-2">
        <h6>Employee Status</h6>
        <ul>
            <li>code name
            <li>1 Contract I</li>
            <li>2 Contract II</li>
            <li>3 Contract III</li>
            <li>4 Probation I</li>
            <li>5 Probation II</li>
            <li>6 Permanent</li>
            <li>7 Daily Worker</li>
            <li>8 Resign</li>
            <li>9 Termination</li>
            <li>10 End of Contract</li>
            <li>11 Unpaid Leave</li>
            <li>12 Contract > III</li>
            <li>13 Black List</li>
        </ul>
    </div>
    <div class="col-md-3">
        <h6>Religion Code</h6>
        <ul>
            <li>code name</li>
            <li>1 Islam</li>
            <li>2 Kristen Protestan</li>
            <li>3 Kristen Katolik</li>
            <li>4 Budha</li>
            <li>5 Hindu</li>
            <li>6 Kong Hu Cu</li>
        </ul>
    </div>
    <div class="col-md-2">

    </div>
</div>