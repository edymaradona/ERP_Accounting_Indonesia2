<?php

$this->widget(
    'booster.widgets.TbToggleButton', [
        'name' => 'testToggleButtonB',
        /* 'options' => array(
          'size' => 'large', //null, 'mini', 'small', 'normal', 'large
          'onColor' => 'success', // 'primary', 'info', 'success', 'warning', 'danger', 'default'
          'offColor' => 'danger',  // 'primary', 'info', 'success', 'warning', 'danger', 'default'
          ) */
    ]
);
